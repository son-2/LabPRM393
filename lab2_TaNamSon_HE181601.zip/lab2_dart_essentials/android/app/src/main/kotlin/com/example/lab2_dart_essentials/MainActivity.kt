package com.example.lab2_dart_essentials

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
