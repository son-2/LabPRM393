import 'dart:async';

void main() async {
  print('===== LAB 3 =====');

  await exercise1();
  await exercise2();
  exercise3();
  exercise4();
  exercise5();
}
/* --------------------------------------------------
   Exercise 1
-------------------------------------------------- */

// Class Product đại diện cho một sản phẩm
class Product {
  int id;        // mã sản phẩm
  String name;   // tên sản phẩm
  double price; // giá sản phẩm

  // Constructor
  Product(this.id, this.name, this.price);
}

// Repository quản lý dữ liệu Product
class ProductRepository {
  // StreamController để phát sản phẩm mới (broadcast cho nhiều listener)
  final _controller = StreamController<Product>.broadcast();

  // Future trả về danh sách sản phẩm (giả lập lấy dữ liệu)
  Future<List<Product>> getAll() async {
    return [
      Product(1, 'Phone', 1000),
      Product(2, 'Laptop', 2000),
    ];
  }

  // Trả ra stream để lắng nghe sản phẩm mới
  Stream<Product> liveAdded() => _controller.stream;

  // Thêm sản phẩm mới vào stream
  void add(Product product) {
    _controller.add(product);
  }
}

Future<void> exercise1() async {
  print('\n--- Exercise 1 ---');

  // Tạo repository
  final repo = ProductRepository();

  // Lấy danh sách sản phẩm bằng Future
  final products = await repo.getAll();
  for (var p in products) {
    print('Product: ${p.name}');
  }

  // Lắng nghe stream sản phẩm mới
  repo.liveAdded().listen((p) {
    print('New product added: ${p.name}');
  });

  // Thêm sản phẩm mới → stream sẽ phát
  repo.add(Product(3, 'Tablet', 500));
}

/* --------------------------------------------------
   Exercise 2
-------------------------------------------------- */

// Class User đại diện cho người dùng
class User {
  String name;   // tên người dùng
  String email;  // email

  User(this.name, this.email);

  // Factory constructor để tạo User từ JSON
  factory User.fromJson(Map<String, dynamic> json) {
    return User(json['name'], json['email']);
  }
}

// Hàm giả lập gọi API và parse JSON
Future<List<User>> fetchUsers() async {
  // Dữ liệu JSON giả lập từ API
  final jsonData = [
    {'name': 'Alice', 'email': 'alice@mail.com'},
    {'name': 'Bob', 'email': 'bob@mail.com'},
  ];

  // Chuyển JSON thành List<User>
  return jsonData.map((e) => User.fromJson(e)).toList();
}

Future<void> exercise2() async {
  print('\n--- Exercise 2 ---');

  // Gọi hàm fetchUsers
  final users = await fetchUsers();
  for (var u in users) {
    print('User: ${u.name} - ${u.email}');
  }
}

/* --------------------------------------------------
   Exercise 3
-------------------------------------------------- */

void exercise3() {
  print('\n--- Exercise 3 ---');

  print('Start'); // chạy ngay

  // Microtask: chạy trước Future
  scheduleMicrotask(() {
    print('Microtask');
  });

  // Future: chạy sau microtask
  Future(() {
    print('Future');
  });

  print('End'); // chạy ngay
}

/* --------------------------------------------------
   Exercise 4
-------------------------------------------------- */

void exercise4() {
  print('\n--- Exercise 4 ---');

  // Tạo stream từ danh sách số
  final stream = Stream.fromIterable([1, 2, 3, 4, 5]);

  stream
      .map((x) => x * x)        // biến đổi: bình phương
      .where((x) => x % 2 == 0) // lọc: chỉ lấy số chẵn
      .listen((value) {
    print(value);           // in kết quả
  });
}

/* --------------------------------------------------
   Exercise 5
-------------------------------------------------- */

// Class Settings dùng Singleton pattern
class Settings {
  // Instance duy nhất
  static final Settings _instance = Settings._internal();

  // Private constructor
  Settings._internal();

  // Factory constructor luôn trả về cùng một instance
  factory Settings() {
    return _instance;
  }
}

void exercise5() {
  print('\n--- Exercise 5 ---');

  // Tạo hai object Settings
  final a = Settings();
  final b = Settings();

  // Kiểm tra xem có phải cùng một object không
  print('Same instance: ${identical(a, b)}');
}
