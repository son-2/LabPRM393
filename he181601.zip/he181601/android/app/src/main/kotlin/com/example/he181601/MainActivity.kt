package com.example.he181601

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
