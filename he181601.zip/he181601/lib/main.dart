import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override //ghi de
  Widget build(BuildContext context) {
    return const MaterialApp(//baogom all map
      debugShowCheckedModeBanner: true,
      home: MyHomePage(title: 'Flutter Layout Demo'),
    );
  }
}

// Màn hình chính
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});//cho phep tao widgte tinh

  final String title; //only duy nhat

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int starCount = 0;

  @override
  Widget build(BuildContext context) {//ve ui
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(1), //tao khoang cach
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // IMAGE
            Image.asset(
              'assets/images/Demo.jpg',
              width: double.infinity,
              height: 200,
              fit: BoxFit.fitHeight,
            ),

            const SizedBox(height: 12),

            // TEXT + STAR
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween, //xep ngang cac phan deu nhau
              children: [
                const Text(
                  'Dong chu to chu in dam',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Text('Dong chu mo chu in thuong',
                style: TextStyle(
                  fontSize: 12,
                      fontWeight: FontWeight.normal,
                  color: Colors.grey,

                )
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.star, color: Colors.orange),
                      onPressed: () {
                        setState(() {//de ve lai ui
                          starCount++;
                        });
                      },
                    ),
                    Text('$starCount'),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 20),

            // DESCRIPTION
            const Text(
              'Đây là một đoạn description. Đây là một đoạn description.Đây là một đoạn description.Đây là một đoạn description. '
                  'Đây là một đoạn description. Đây là một đoạn description.Đây là một đoạn description.Đây là một đoạn description. '
                  'Đây là một đoạn description. Đây là một đoạn description.Đây là một đoạn description.Đây là một đoạn description. '
                  'Đây là một đoạn description. Đây là một đoạn description.Đây là một đoạn description.Đây là một đoạn description. '
                  'Đây là một đoạn description. Đây là một đoạn description.Đây là một đoạn description.Đây là một đoạn description. '
                  'Đây là một đoạn description. Đây là một đoạn description.Đây là một đoạn description.Đây là một đoạn description. '
                  'Đây là một đoạn description. Đây là một đoạn description.Đây là một đoạn description.Đây là một đoạn description. '
                 ,
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}
