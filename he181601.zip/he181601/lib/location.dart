import 'dart:async';

class Location {
  int id;
  String name;
  String address;
  String description;
  double star;
  Location(this.id, this.name, this.address, this.description, this.star);

}
